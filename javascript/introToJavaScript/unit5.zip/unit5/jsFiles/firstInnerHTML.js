/*
    This is file /unit5/firstInnerHTML.js 
    It contains the JavaScript code for
    
    "Starting to Integrate JavaScript and HTML" File: /unit5/firstInnerHTML.html
*/
function firstInnerHTML() {
    // Your code goes in here.
    
    document.write("The JavaScript file for this page is: "
            + "\"/unit5/jsFiles/firstInnerHTML.js\"");
}