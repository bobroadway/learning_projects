/*
    This is the JavaScript code for 
    "Project 5" 
    File: /unit5/project/project5.html
*/
function project5() {
    // Your code goes in here.
    
    document.write("The JavaScript file for this page is: "
            + "\"/unit5/jsFiles/project5.js\"");
}