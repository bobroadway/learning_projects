/*
    This is file /unit5/scope.js 
    It contains the JavaScript code for
    
    "Variable Scope" File: /unit5/scope.html
*/
function scope() {
    // Your code goes in here.
    
    document.write("The JavaScript file for this page is: "
            + "\"/unit5/jsFiles/scope.js\"");
}