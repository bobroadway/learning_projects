/*
    This is file /unit5/jsLintUsage.js 
    It contains the JavaScript code for
    
    "Using jsLint" File: /unit5/jsLintUsage.html
*/
function jsLintUsage() {
    // Your code goes in here.
    var output;
    
    output = document.getElementById('outputDiv');
    
    output.innerHTML = "The JavaScript file for this page is: "
            + "\"/unit5/jsFiles/jsLintUsage.js\"";
}