/*
    This is file /unit5/functionToFunction.js 
    It contains the JavaScript code for
    
    "Function To Function - How Functions Communicate" File: /unit5/functionToFunction.html
*/
function functionToFunction() {
    // Your code goes in here.
    
    document.write("The JavaScript file for this page is: "
            + "\"/unit5/jsFiles/functionToFunction.js\"");
}