function lab01movingJavaScript() {

    var firstName;
    var lastName;
    
    firstName = "Wilma";
    lastName = "Flintstone";
    
    document.write("Hello, " + firstName + " " + lastName);
    
}
