/*
    This is the JavaScript code for 
    "A Quick Introduction to Functions" 
    File: /unit4/introToFunctions.html
*/
function introToFunctions() {
    // Your code goes in here.
    document.write("The JavaScript file for this page is: " 
            + "\"/unit4/jsFiles/introToFunctions.js\"");
}
