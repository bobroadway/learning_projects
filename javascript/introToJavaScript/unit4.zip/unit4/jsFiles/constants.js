/*
    This is file /unit4/constants.js 
    It contains the JavaScript code for
    
    "Constants in JavaScript" File: /unit4/constants.html
*/
function constants() {
    // Your code goes in here.
    
    document.write("The JavaScript file for this page is: "
            + "\"/unit4/jsFiles/constants.js\"");
}