/*
    This is the JavaScript code for 
    "Project 4" 
    File: /unit4/project/project4.html
*/
function project4() {
    // Your code goes in here.
    
    document.write("This file is here: "
            + "\"/unit4/project/project4.js\"");
}